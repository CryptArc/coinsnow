<template>
  <div id="app">
     <main-view></main-view>
  </div>
</template>

<script>
      import MainView from '@/components/Main'
      export default {
            name: 'app',
            components: {
                  MainView
            }
      }
</script>
